package canteen;


import java.awt.Graphics;

public interface DisplayObject {
	public void draw(Graphics g);
}
