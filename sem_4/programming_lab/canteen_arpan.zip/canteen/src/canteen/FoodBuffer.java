package canteen;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.util.Random;

import javax.swing.JLabel;

public class FoodBuffer  implements DisplayObject {
	
	Food[] foods = null;
	int produceIndex;
	int consumeIndex;
	
	public FoodBuffer(int size) {
		foods = new Food[size];
		this.produceIndex = size-1;
		this.consumeIndex = size-1;
	}

	@Override
	public void draw(Graphics g) {
		for(Food f : foods) {
			if(f != null)
				f.draw(g);
		}
	}
	
	public void produce(Food f, int index, int x, int y) {
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
//		int startX = (int)(screenSize.getWidth()/2) - 250;
//		int startY = (int)(screenSize.getHeight()/2) - 25;
		int startX = x - 550;
		int startY = y;
		f.x = startX+ index*50 + 5;
		f.y = startY + 5;
		foods[index] = f;
	}
	
	public synchronized void addFood(int x, int y) {
		if((this.produceIndex + 1)%10 == this.consumeIndex) {
			System.out.println("Food buffer is full!");
		}else {
			Random rnd = new Random();
			this.produceIndex = (this.produceIndex + 1)%10;
			Food f = new Food(FoodType.values()[rnd.nextInt(4)]);
			this.produce(f, this.produceIndex, x, y);	
			System.out.println("Chef has produced: "+ f.type);
		}
	}
	
	public synchronized void consume() {
		if(this.consumeIndex == this.produceIndex) {
			System.out.println("Food buffer is empty!");
		}else {
			this.consumeIndex = (this.consumeIndex + 1)%10;
			System.out.println("Student consumed: "+ foods[this.consumeIndex].type);
			this.foods[this.consumeIndex] = null;
		}
	}

}
