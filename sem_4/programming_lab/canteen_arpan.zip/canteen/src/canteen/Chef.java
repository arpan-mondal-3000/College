package canteen;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

/**
 * 
 * @author Sunirmal Khatua
 *
 */
public class Chef extends Thread implements DisplayObject {

	private Image img;
	private int x,y;
	
	ArrayList<Student> students = null;
	
	public Chef(int x, int y) {
		this.x=x;
		this.y=y;
		img = new ImageIcon(getClass().getResource("/images/chef.png")).getImage();
	}
	
	
	@Override
	public void draw(Graphics g) {
		g.drawImage(img,x,y,70,70,null);
	}
	
	@Override
	public void run() {
		while(true) {
			for(Student s: students) {
				try {
					Thread.sleep((int)(Math.random()*500)+100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				
				s.foods.addFood(s.x, s.y);
				
				try {
					Thread.sleep((int)(Math.random()*500)+100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
